#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
from ultralytics import YOLO


class ImageSubscriber(Node):

    def __init__(self):
        super().__init__('image_subscriber')
        
        # IMPORTANT: update this to your real gazebo image topic
        self.subscription = self.create_subscription(
            Image,
            '/camera',         # <-- change this after checking ros2 topic list
            self.listener_callback,
            10
        )

        self.br = CvBridge()

        # Load YOLO model
        self.get_logger().info("Loading YOLOv8 model...")
        self.model = YOLO('yolov8m.pt')
        self.get_logger().info("YOLO model loaded successfully!")

    def listener_callback(self, data):
        self.get_logger().info('Receiving video frame')

        # Convert ROS -> OpenCV
        frame = self.br.imgmsg_to_cv2(data, "bgr8")

        # Run YOLO detection (persons: 0, cars: 2)
        results = self.model(frame, classes=[0, 2])

        # Draw prediction results
        annotated = results[0].plot()

        # Show frame
        cv2.imshow("YOLO Detection", annotated)
        cv2.waitKey(1)


def main(args=None):
    rclpy.init(args=args)
    node = ImageSubscriber()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    node.destroy_node()
    cv2.destroyAllWindows()
    rclpy.shutdown()


if __name__ == "__main__":
    main()

