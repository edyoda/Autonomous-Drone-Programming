#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from px4_msgs.msg import ObstacleDistance
import time
import math

class LaserToObstacleDistance(Node):

    def __init__(self):
        super().__init__('laser_to_obstacle_distance')

        self.sub = self.create_subscription(
            LaserScan,
            '/scan',
            self.scan_cb,
            10
        )

        self.pub = self.create_publisher(
            ObstacleDistance,
            '/fmu/in/obstacle_distance',
            10
        )

        self.get_logger().info("LaserScan → ObstacleDistance bridge started")

    def scan_cb(self, scan: LaserScan):
        msg = ObstacleDistance()

        # PX4 requires non-zero timestamp (µs)
        msg.timestamp = int(time.time() * 1e6)

        # PX4 expects BODY frame
        msg.frame = ObstacleDistance.MAV_FRAME_BODY_FRD
        msg.sensor_type = ObstacleDistance.MAV_DISTANCE_SENSOR_LASER

        # Convert radians → degrees
        msg.angle_offset = math.degrees(scan.angle_min)
        msg.increment = math.degrees(scan.angle_increment)

        msg.min_distance = int(scan.range_min * 100)
        msg.max_distance = int(scan.range_max * 100)

        distances = []

        for r in scan.ranges:
            if math.isinf(r) or math.isnan(r):
                distances.append(65535)  # UNKNOWN
            else:
                d_cm = int(r * 100)
                if d_cm < msg.min_distance:
                    d_cm = msg.min_distance
                if d_cm > msg.max_distance:
                    distances.append(msg.max_distance + 1)  # NO OBSTACLE
                else:
                    distances.append(d_cm)

        # PX4 expects EXACTLY 72 elements
        if len(distances) > 72:
            distances = distances[:72]
        elif len(distances) < 72:
            distances.extend([65535] * (72 - len(distances)))

        msg.distances = distances

        self.pub.publish(msg)

        self.get_logger().info(
            "Published ObstacleDistance",
            throttle_duration_sec=1.0
        )

def main():
    rclpy.init()
    node = LaserToObstacleDistance()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()

